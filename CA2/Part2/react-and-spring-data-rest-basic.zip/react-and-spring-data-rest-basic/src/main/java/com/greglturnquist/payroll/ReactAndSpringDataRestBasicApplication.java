package com.greglturnquist.payroll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactAndSpringDataRestBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactAndSpringDataRestBasicApplication.class, args);
	}

}
